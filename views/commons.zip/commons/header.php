<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="contact" content="info@entol.net" />
        <meta name="copyright" content="entol.net" />
        <meta name="Keywords" content="<?php if ($active_menu == "read") echo $meta_tag ;?> <?php echo ($active_menu == "home" || $active_menu == "blog"  || $active_menu == "shop" || $active_menu == "portofolio"  || $active_menu == "contact"|| $active_menu == "about") ? "Entol, Entol.net,Freelance, Web Developer, web programmer, web, web designer, web design, website, situs, developer, programmer, tutorial, php, database, mysql, postgresql, wap, web2sms, freelance, freelancer, cms, content management system, new media design, web standard, Banten,Jakarta,Bandung, web bussiness" :  ""; echo ($active_menu == "blog") ? "tutorial, php, database, mysql,tips,trik,Web,Aplication,codeigniter,jasperserver,ireport" : ""; ?>">
        <meta name="description" content="<?php echo ($active_menu == "home") ? "Entol.net Is Profesional Freelance Web Developer +62 7696 0473 based In Banten 42466 Indonesia" : ""; echo ($active_menu == "blog" || $active_menu == "portofolio"  || $active_menu == "contact"|| $active_menu == "about") ? "We are a creative team and make great web things since 2013 based in Banten, Indonesia. We've done many web Application And static projects, with expertise in building websites using Codeigniter Framework, also CMS like Wordpress,Joomla,Drupal ,Entol.net also offers to build websites using Responsive Web Design technology. Our passion for design goes beyond beautiful imagery and into the mind of the consumer, where we believe good design should solve problems and position a brand so it stands out as well as stands for something." : ""; ?>">
        <meta name="author" content="<?php echo ($active_menu == "home") ? "Entol" : ""; ?>">
        <meta name='yandex-verification' content=''/>
        <meta name='baidu-site-verification' content=''/>
        <meta name='alexaVerifyID' content='' />
        <meta name='geo.country' content='id' />
        <meta name='language' content='id-us-en' />
        <meta name="twitter:card" content="summary">
        <meta name="twitter:site" content="@entolfakih">
        <meta name="twitter:title" content="<?php if ($active_menu == "read") echo $meta_judul ;?><?php echo ($active_menu == "home") ? "Entol.net | Freelance Web Developer" : "";echo ($active_menu == "contact") ? "Entol.net | Contact " : ""; echo ($active_menu == "portofolio") ? "Entol.net | Portofolio " : ""; echo ($active_menu == "about") ? "Entol.net | About " : ""; echo ($active_menu == "blog") ? "Entol.net | Blog " : ""; ?>">
        <meta name="twitter:description" content="<?php echo ($active_menu == "home") ? "Entol.net Is Profesional Freelance Web Developer +62 7696 0473 based In Banten 42466 Indonesia" : ""; ?>">
        <meta name="twitter:creator" content="@entolfakih">
        <meta name="twitter:image" content="<?php echo base_url(); ?>uploads/<?php if ($active_menu == "read") echo $meta_foto ; else echo 'entol_net.png ' ;?>">
        <meta property="og:title" content="<?php if ($active_menu == "read") echo $meta_judul ;?><?php echo ($active_menu == "home") ? "Entol.net | Freelance Web Developer" : "";echo ($active_menu == "contact") ? "Entol.net | Contact " : ""; echo ($active_menu == "portofolio") ? "Entol.net | Portofolio " : ""; echo ($active_menu == "about") ? "Entol.net | About " : ""; echo ($active_menu == "blog") ? "Entol.net | Blog " : ""; ?>" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="<?php function url_origin( $s, $use_forwarded_host = false )
                                          {
                                            $ssl      = ( ! empty( $s['HTTPS'] ) && $s['HTTPS'] == 'on' );
                                            $sp       = strtolower( $s['SERVER_PROTOCOL'] );
                                            $protocol = substr( $sp, 0, strpos( $sp, '/' ) ) . ( ( $ssl ) ? 's' : '' );
                                            $port     = $s['SERVER_PORT'];
                                            $port     = ( ( ! $ssl && $port=='80' ) || ( $ssl && $port=='443' ) ) ? '' : ':'.$port;
                                            $host     = ( $use_forwarded_host && isset( $s['HTTP_X_FORWARDED_HOST'] ) ) ? $s['HTTP_X_FORWARDED_HOST'] : ( isset( $s['HTTP_HOST'] ) ? $s['HTTP_HOST'] : null );
                                            $host     = isset( $host ) ? $host : $s['SERVER_NAME'] . $port;
                                            return $protocol . '://' . $host;
                                            }

                                            function full_url( $s, $use_forwarded_host = false )
                                            {
                                                return url_origin( $s, $use_forwarded_host ) . $s['REQUEST_URI'];
                                            }
                                            $absolute_url = full_url( $_SERVER );
                                            echo $absolute_url;?>" />
        <meta property="og:image" content="<?php echo base_url(); ?>uploads/<?php if ($active_menu == "read") echo $meta_foto ; else echo 'entol_net.png ' ;?>" />
        <meta property="og:description" content="" />
        <meta property="og:site_name" content="entol.net" />
        <meta property="fb:admins" content="100001978213177" />
        <meta name="google-site-verification" content="" />
        <title><?php if ($active_menu == "read") echo $meta_judul ;?><?php echo ($active_menu == "home") ? "Entol.net | Freelance Web Developer" : "";echo ($active_menu == "contact") ? "Entol.net | Contact " : ""; echo ($active_menu == "portofolio") ? "Entol.net | Portofolio " : ""; echo ($active_menu == "about") ? "Entol.net | About " : ""; echo ($active_menu == "blog") ? "Entol.net | Blog " : ""; ?></title>
        <link rel="canonical" href="<?php $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; echo $actual_link ;?>" />
        <link rel='publisher' href='https://plus.google.com/+entolfakih/posts' />
        <link rel='author' href='https://plus.google.com/u/+entolfakih/about' />
        <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/img/entol.png">
        <!-- Bootstrap -->
        <link href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- custom css (blue color by default) -->
        <link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet" type="text/css" media="screen">
        <!-- custom css (green color ) -->
        <!--      <link href="css/style-green.css" rel="stylesheet" type="text/css" media="screen">-->
        <!-- custom css (red color ) -->
        <!--        <link href="css/style-red.css" rel="stylesheet" type="text/css" media="screen">-->
        <!-- custom css (yellow color ) -->
        <!--       <link href="css/style-yellow.css" rel="stylesheet" type="text/css" media="screen">-->
        <!-- custom css (sea-greean color ) -->
        <!--      <link href="css/style-sea-green.css" rel="stylesheet" type="text/css" media="screen">-->
        <!-- custom css (style-gold color ) -->
        <!--       <link href="css/style-gold.css" rel="stylesheet" type="text/css" media="screen">-->
        <!-- font awesome for icons -->
        <link href="<?php echo base_url();?>assets/font-awesome-4.3.0/css/font-awesome.min.css" rel="stylesheet">
        <!-- flex slider css -->
        <link href="<?php echo base_url();?>assets/css/flexslider.css" rel="stylesheet" type="text/css" media="screen">
        <!-- animated css  -->
        <link href="<?php echo base_url();?>assets/css/animate.css" rel="stylesheet" type="text/css" media="screen">
        <!--google fonts-->


        <link href='http://fonts.googleapis.com/css?family=Raleway:400,500,600,700,800' rel='stylesheet' type='text/css'>
        <!--owl carousel css-->
        <link href="<?php echo base_url();?>assets/css/owl.carousel.css" rel="stylesheet" type="text/css" media="screen">
        <link href="<?php echo base_url();?>assets/css/owl.theme.css" rel="stylesheet" type="text/css" media="screen">
        <!--mega menu -->
        <link href="<?php echo base_url();?>assets/css/yamm.css" rel="stylesheet" type="text/css">
        <!--popups css-->
        <link href="<?php echo base_url();?>assets/css/magnific-popup.css" rel="stylesheet" type="text/css">
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>
    <body>

        <div id="header-top" class="hidden-xs">
            <div class="container">
                <div class="top-bar">
                    <div class="pull-left sample-1right">
                        <a><i class="fa fa-phone"></i> Any questions? Call us: <span class="colored-text"><?php echo phone;?></span> </a>
                         <a><i class="fa fa-envelope"></i> Mail us: <span class="colored-text"><?php echo mail;?></span> </a>
                    </div>
                    <div class="pull-right">
                        <ul class="list-inline top-social">
                            <li>Follow us:</li>
                            <li><a href="<?php echo facebook;?>"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="<?php echo twitter;?>"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="<?php echo google_plus;?>"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="<?php echo linkedin;?>"><i class="fa fa-linkedin"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div><!--top bar end hidden in small devices-->
        <!--navigation -->
        <!-- Static navbar -->
        <div class="navbar navbar-default navbar-static-top yamm sticky" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="<?php echo base_url();?>"><img src="<?php echo base_url();?>/assets/img/black_pink.png" width="225" height="50" alt="entol.net"></a>
                </div>
                <div  class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="<?php echo ($active_menu == "home") ? "active" : ""; ?>">
                            <a href="<?php echo base_url();?>" >Home </a>
                        </li>
                        <!--menu home li end here-->
                        <li class="<?php echo ($active_menu == "portofolio") ? "active" : ""; ?>">
                            <a href="<?php echo base_url();?>portofolio">Portofolio </a>
                        </li>
                        <!--menu Portfolio li end here-->
                        <li class="<?php echo ($active_menu == "blog") ? "active" : ""; ?>">
                            <a href="<?php echo base_url();?>blog">BLOG </a>
                        </li>
                        <!--menu blog li end here-->
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">About <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="<?php echo base_url();?>about">About Us</a></li>
                                <li><a href="process.html">Our Process</a></li>
                                <li><a href="pricing.html">Our Pricing</a></li>
                                <li><a href="gallery.html">Gallery</a></li>
                            </ul>
                        </li>
                        <li class="<?php echo ($active_menu == "shop") ? "active" : ""; ?>">
                            <a href="<?php echo base_url();?>shop">Shop </a>
                        </li>
                        <li class="<?php echo ($active_menu == "contact") ? "active" : ""; ?>">
                            <a href="<?php echo base_url();?>contact">Contact </a>
                        </li>
                        <li class="dropdown " data-animate="animated fadeInUp" style="z-index:500;">
                            <a href="#" class="dropdown-toggle " data-toggle="dropdown"><i class="fa fa-search"></i></a>
                            <ul class="dropdown-menu search-dropdown animated fadeInUp">
                                <li id="dropdownForm">
                                    <div class="dropdown-form">
                                        <form class=" form-inline">
                                            <div class="input-group">
                                                <input type="text" class="form-control" placeholder="search...">
                                                <span class="input-group-btn">
                                                    <button class="btn btn-theme-bg" type="button">Go!</button>
                                                </span>
                                            </div><!--input group-->
                                        </form><!--form-->
                                    </div><!--.dropdown form-->
                                </li><!--.drop form search-->
                            </ul><!--.drop menu-->
                        </li> <!--menu search li end here-->
                        <li class="dropdown">
                            <a href="#" class=" dropdown-toggle" data-toggle="dropdown"><i class="fa fa-lock"></i></a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-login-box animated fadeInUp">
                                <form role="form">
                                    <h4>Signin</h4>

                                    <div class="form-group">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                            <input type="text" class="form-control" placeholder="Username">
                                        </div>
                                        <br>
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                            <input type="password" class="form-control" placeholder="Password">
                                        </div>
                                        <div class="checkbox pull-left">
                                            <label>
                                                <input type="checkbox"> Remember me
                                            </label>
                                        </div>
                                        <a class="btn btn-theme-bg pull-right">Login</a>
                                        <!--                                        <button type="submit" class="btn btn-theme pull-right">Login</button>                 -->
                                        <div class="clearfix"></div>
                                        <hr>
                                        <p>Don't have an account! <a href="#">Register Now</a></p>
                                    </div>
                                </form>
                            </div>
                        </li> <!--menu login li end here-->

                    </ul>
                </div><!--/.nav-collapse -->
            </div><!--container-->
        </div><!--navbar-default-->
