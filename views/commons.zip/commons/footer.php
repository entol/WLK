

        <div class="divide60"></div>
        <footer id="footer">
            <div class="container">

                <div class="row">
                    <div class="col-md-3 col-sm-6 margin30">
                        <div class="footer-col">
                            <h3>About <?php echo site_name;?></h3>
                            <p>
                                <?php echo site_info;?>
                            </p>
                            <ul class="list-inline social-1">
                                <li><a href="<?php echo facebook;?>"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="<?php echo twitter;?>"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="<?php echo linkedin;?>"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="<?php echo google_plus;?>"><i class="fa fa-google-plus"></i></a></li>
                            </ul>
                        </div>
                    </div><!--footer col-->
                    <div class="col-md-3 col-sm-6 margin30">
                        <div class="footer-col">
                            <h3>Contact</h3>

                            <ul class="list-unstyled contact">
                                <li><p><strong><i class="fa fa-map-marker"></i> Address:</strong> <?php echo address;?></p></li>
                                <li><p><strong><i class="fa fa-envelope"></i> Mail Us:</strong> <a href="#"><?php echo mail;?></a></p></li>
                                <li> <p><strong><i class="fa fa-phone"></i> Phone:</strong> <?php echo phone;?></p></li>
                                <li> <p><strong><i class="fa fa-print"></i> Fax</strong> <?php echo fax;?></p></li>
                                <li> <p><strong><i class="fa fa-skype"></i> Skype</strong> <?php echo skype ;?></p></li>

                            </ul>
                        </div>
                    </div><!--footer col-->
                    <div class="col-md-3 col-sm-6 margin30">
                        <div class="footer-col">
                            <h3>Latest Tweet</h3>
                              <a class="twitter-timeline" href="https://twitter.com/entolfakih" data-widget-id="463381300917723136">Tweet oleh @entolfakih</a>
                              <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
                          </div>
                    </div><!--footer col-->
                    <div class="col-md-3 col-sm-6 margin30">
                        <div class="footer-col">
                            <h3>Newsletter</h3>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer lorem quam,
                            </p>
                            <form role="form" class="subscribe-form">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Enter email to subscribe">
                                    <span class="input-group-btn">
                                        <button class="btn  btn-theme-dark btn-lg" type="submit">Ok</button>
                                    </span>
                                </div>
                            </form>
                        </div>
                    </div><!--footer col-->

                </div>
                <div class="row">
                    <div class="col-md-12 text-right">
                        <div class="footer-btm">
                            <span> Copyright &copy; 2013-<?php echo date('Y'); ?>. <a href="<?php echo base_url();?>">Entol.net</a>. All rights reserved.</span>
                        </div>
                    </div>
                </div>
            </div>
        </footer><!--default footer end here-->
       <!--scripts and plugins -->
        <script src="https://apis.google.com/js/platform.js" async defer></script>
        <!--must need plugin jquery-->
        <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
        <!--bootstrap js plugin-->
        <script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <!--easing plugin for smooth scroll-->
        <script src="<?php echo base_url();?>assets/js/jquery.easing.1.3.min.js" type="text/javascript"></script>
        <!--sticky header-->
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.sticky.js"></script>
        <!--flex slider plugin-->
        <script src="<?php echo base_url();?>assets/js/jquery.flexslider-min.js" type="text/javascript"></script>
        <!--parallax background plugin-->
        <script src="<?php echo base_url();?>assets/js/jquery.stellar.min.js" type="text/javascript"></script>
        <!--very easy to use portfolio filter plugin -->
        <script src="<?php echo base_url();?>assets/js/jquery.mixitup.min.js" type="text/javascript"></script>
        <!--digit countdown plugin-->
        <script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
        <!--digit countdown plugin-->
        <script src="<?php echo base_url();?>assets/js/jquery.counterup.min.js" type="text/javascript"></script>
        <!--on scroll animation-->
        <script src="<?php echo base_url();?>assets/js/wow.min.js" type="text/javascript"></script>
        <!--owl carousel slider-->
        <script src="<?php echo base_url();?>assets/js/owl.carousel.min.js" type="text/javascript"></script>
        <!--popup js-->
        <script src="<?php echo base_url();?>assets/js/jquery.magnific-popup.min.js" type="text/javascript"></script>
        <!--you tube player-->
        <script src="<?php echo base_url();?>assets/js/jquery.mb.YTPlayer.min.js" type="text/javascript"></script>
        <!--text rotator-->
        <script src="<?php echo base_url();?>assets/js/jquery.simple-text-rotator.js" type="text/javascript"></script>
        <!--customizable plugin edit according to your needs-->
        <script src="<?php echo base_url();?>assets/js/index.min.js"></script>
        <script src="<?php echo base_url();?>assets/js/jquery.counterup.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/js/custom.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/js/typed.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/js/jquery.countdown.js" type="text/javascript"></script>
        <script type="text/javascript">
            /* Typed
                ================================================== */
                $(".element").each(function(){
                    var $this = $(this);
                    $this.typed({
                    strings: $this.attr('data-elements').split(','),
                    typeSpeed: 100, // typing speed
                    backDelay: 3000 // pause before backspacing
                    });
                });
        </script>
        <script type="text/javascript">
            $(function() {
                var austDay = new Date();
                austDay = new Date(austDay.getFullYear() + 1, 1 - 1,-300);
                $('#shop').countdown({until: austDay});
                $('#year').text(austDay.getFullYear());
            });
        </script>
        <!--gmap js-->
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=true"></script>
        <script type="text/javascript">
            var myLatlng;
            var map;
            var marker;

            function initialize() {
                myLatlng = new google.maps.LatLng(-6.057035, 105.914418);

                var mapOptions = {
                    zoom: 13,
                    center: myLatlng,
                    mapTypeId: google.maps.MapTypeId.ROADMAP,
                    scrollwheel: false,
                    draggable: false
                };
                map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);

                var contentString = '<p style="line-height: 20px;"><strong>Skripsi Stikom Al-Khairiyah</strong></p><p>Anyer Serang, Banten, 42446</p> ';

                var infowindow = new google.maps.InfoWindow({
                    content: contentString
                });

                marker = new google.maps.Marker({
                    position: myLatlng,
                    map: map,
                    title: 'Marker'
                });

                google.maps.event.addListener(marker, 'click', function() {
                    infowindow.open(map, marker);
                });
            }

            google.maps.event.addDomListener(window, 'load', initialize);
        </script>
        <script>
  			  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  			  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  			  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  			  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  			  ga('create', 'UA-56272515-1', 'auto');
  			  ga('send', 'pageview');

  			</script>
    </body>
</html>
