<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Mandiri Syariah | Administrator </title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->

    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
     <link href="<?php echo base_url();?>assets/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>assets/dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    
    
    <link href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
  
    <link href="<?php echo base_url();?>assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="<?php echo base_url();?>assets/css/font-awesome.min.css" rel="stylesheet" />
    <!-- FontAwesome 4.3.0 -->
    <link href="<?php echo base_url();?>assets/css/entol.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>assets/plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <!--link href="<?php echo base_url();?>assets/plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" /-->
    <!-- Date Picker -->
    <link href="<?php echo base_url();?>assets/plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="<?php echo base_url();?>assets/plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="<?php echo base_url();?>assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
	
	<!--script type="text/javascript" src="<?php echo base_url();?>assets/plugins/jQuery/jQuery-2.1.3.min.js"></script-->

  <script type="text/javascript" src="<?php echo base_url();?>assets/plugins/jQuery/jQuery-2.1.3.min.js"></script>

	

  </head>
   <body class="skin-black">
    <div class="wrapper">

      <header class="main-header">
        <!-- Logo -->
         <a href="<?php echo base_url();?>" class="logo hidden-xs"><img src="<?php echo base_url();?>assets/img/Mandiri-Syariah.png" class="img-responsive"></a> 
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Messages: style can be found in dropdown.less-->

              <!-- Notifications: style can be found in dropdown.less -->
               <!-- Navbar Right Menu
			   transport
				   transport cilegon
				   damtruk
					-
				   maintenance







			   -->

              <!-- Tasks: style can be found in dropdown.less -->

              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="<?php echo base_url();?>profile" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="<?php echo base_url();?>uploads/<?php echo foto;?>" class="user-image" alt="User Image"/>
                  <span class="hidden-xs"><?php echo USER_NAME;?></span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    <img src="<?php echo base_url();?>uploads/<?php echo foto;?>" class="img-circle" alt="User Image" />
                    <p>
                     <?php echo USER_NAME;?> -<?php echo email;?>
                      <small>Member since Nov. 2012</small>
                    </p>
                  </li>
                  <!-- Menu Body -->
                  <li class="user-body">
                    <div class="col-xs-4 text-center">
                      <a href="#">Followers</a>
                    </div>
                    <div class="col-xs-4 text-center">
                      <a href="#">Sales</a>
                    </div>
                    <div class="col-xs-4 text-center">
                      <a href="#">Friends</a>
                    </div>
                  </li>
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-left">
                      <a href="<?php echo base_url();?>auth/change_password" class="btn btn-default btn-flat"> <i class="glyphicon glyphicon-edit"> </i>  Change Password</a>
                    </div>
                    <div class="pull-right">
                      <a href="<?php echo base_url();?>auth/logout" class="btn btn-default btn-flat"><i class="glyphicon glyphicon-off"> </i> Sign out</a>
                    </div>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
		   <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Messages: style can be found in dropdown.less-->
              
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="<?php echo base_url();?>uploads/<?php echo foto;?>" class="img-circle" alt="User Image" />
            </div>
            <div class="pull-left info">
              <p> <a href="<?php echo base_url();?>profile"><?php echo USER_NAME;?></a></p>

              <a href="<?php echo base_url();?>profile"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>
          <!-- search form -->
          <!-- /.search form -->
          <!-- sidebar menu: : style can be found in sidebar.less -->
<?php if(default_group =="Admin"  ){ ?> 

          <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li class="<?php echo ($activeMenu == "dashboard") ? "active  treeview" : ""; ?>">
              <a href="<?php echo base_url();?>dashboard">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
              </a>
            </li>
            <li class="treeview <?php echo ($activeMenu == "master") ? "active" : ""; ?>">
                   <a href="#">
                     <i class="glyphicon glyphicon-hdd"></i> <span>Master</span>
                     <i class="fa fa-angle-left pull-right"></i>
                   </a>
                   
                   <ul class="treeview-menu">
                     <li class="<?php echo ($activeTab == "users") ? "active" : ""; ?>"><a href="<?php echo base_url();?>users"><i class="fa fa-circle-o"></i> Users</a></li>
                     <li class="<?php echo ($activeTab == "mutasi_m_jenis_transaksi") ? "active" : ""; ?>"><a href="<?php echo base_url();?>mutasi_m_jenis_transaksi"><i class="fa fa-circle-o"></i> Jenis Transaksi</a></li>
                     <li class="<?php echo ($activeTab == "mutasi_m_status_transaksi") ? "active" : ""; ?>"><a href="<?php echo base_url();?>mutasi_m_status_transaksi"><i class="fa fa-circle-o"></i> Status Transaksi</a></li>
            

                    </ul>
           </li>
           <li class="treeview <?php echo ($activeMenu == "transaksi") ? "active" : ""; ?>">
                  <a href="#">
                    <i class="glyphicon glyphicon-transfer"></i> <span>Transaction</span>
                    <i class="fa fa-angle-left pull-right"></i>
                  </a>
                  <ul class="treeview-menu">
                    <li class="<?php echo ($activeTab == "acounting") ? "active" : ""; ?>"><a href="<?php echo base_url();?>acounting"><i class="fa fa-circle-o"></i> Halaman Acounting</a></li>
                    <li class="<?php echo ($activeTab == "pengiriman") ? "active" : ""; ?>"><a href="<?php echo base_url();?>pengiriman"><i class="fa fa-circle-o"></i> Halaman Pengiriman</a></li>

                   </ul>
          </li>

          <li class="treeview <?php echo ($activeMenu == "report") ? "active" : ""; ?>">
                 <a href="#">
                   <i class="glyphicon glyphicon-tasks"></i> <span>Reports</span>
                   <i class="fa fa-angle-left pull-right"></i>
                 </a>
                 <ul class="treeview-menu">
                   <li class="<?php echo ($activeTab == "report_permintaan") ? "active" : ""; ?>"><a href="<?php echo base_url();?>report_permintaan"><i class="fa fa-circle-o"></i> Report</a></li>
                  </ul>
         </li>


            </ul>
            <?php }?>
<?php if(default_group =="Acounting"  ){ ?> 

          <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li class="<?php echo ($activeMenu == "dashboard") ? "active  treeview" : ""; ?>">
              <a href="<?php echo base_url();?>dashboard">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
              </a>
            </li>
            <li class="treeview <?php echo ($activeMenu == "master") ? "active" : ""; ?>">
                   <a href="#">
                     <i class="glyphicon glyphicon-hdd"></i> <span>Master</span>
                     <i class="fa fa-angle-left pull-right"></i>
                   </a>
                   
                   <ul class="treeview-menu">
                     <li class="<?php echo ($activeTab == "users") ? "active" : ""; ?>"><a href="<?php echo base_url();?>users"><i class="fa fa-circle-o"></i> Users</a></li>
                     <li class="<?php echo ($activeTab == "barang") ? "active" : ""; ?>"><a href="<?php echo base_url();?>barang"><i class="fa fa-circle-o"></i> Barang</a></li>
                     <li class="<?php echo ($activeTab == "karyawan") ? "active" : ""; ?>"><a href="<?php echo base_url();?>karyawan"><i class="fa fa-circle-o"></i> Karyawan</a></li>
                      <!--li class="<!?php echo ($activeTab == "purchase_order") ? "active" : ""; ?>"><a href="<!?php echo base_url();?>purchase_order"><i class="fa fa-circle-o"></i> Purchase Order<span class="label label-primary  pull-right"><!?php echo jumlah_pr_id_outstanding;?></span> </a></li-->
             <li class="<?php echo ($activeTab == "suplier") ? "active" : ""; ?>"><a href="<?php echo base_url();?>suplier"><i class="fa fa-circle-o"></i> Suplier</a></li>
            

                    </ul>
           </li>
           <li class="treeview <?php echo ($activeMenu == "transaksi") ? "active" : ""; ?>">
                  <a href="#">
                    <i class="glyphicon glyphicon-transfer"></i> <span>Transaction</span>
                    <i class="fa fa-angle-left pull-right"></i>
                  </a>
                  <ul class="treeview-menu">
                    <li class="<?php echo ($activeTab == "permintaan") ? "active" : ""; ?>"><a href="<?php echo base_url();?>permintaan"><i class="fa fa-circle-o"></i> Permintaan</a></li>
                    <li class="<?php echo ($activeTab == "pembelian") ? "active" : ""; ?>"><a href="<?php echo base_url();?>pembelian"><i class="fa fa-circle-o"></i> Pembelian</a></li>

                   </ul>
          </li>

          <li class="treeview <?php echo ($activeMenu == "report") ? "active" : ""; ?>">
                 <a href="#">
                   <i class="glyphicon glyphicon-tasks"></i> <span>Reports</span>
                   <i class="fa fa-angle-left pull-right"></i>
                 </a>
                 <ul class="treeview-menu">
                   <li class="<?php echo ($activeTab == "report_permintaan") ? "active" : ""; ?>"><a href="<?php echo base_url();?>report_permintaan"><i class="fa fa-circle-o"></i> Laporan Permintaan</a></li>
                   <li class="<?php echo ($activeTab == "report_pembelian") ? "active" : ""; ?>"><a href="<?php echo base_url();?>report_pembelian"><i class="fa fa-circle-o"></i> Laporan Pembelian</a></li>
           <li class="<?php echo ($activeTab == "stok") ? "active" : ""; ?>"><a href="<?php echo base_url();?>stock"><i class="fa fa-circle-o"></i> Stok</a></li>
                  </ul>
         </li>


            </ul>
            <?php }?>
<?php if(default_group =="Pengiriman"  ){ ?> 

          <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li class="<?php echo ($activeMenu == "dashboard") ? "active  treeview" : ""; ?>">
              <a href="<?php echo base_url();?>dashboard">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
              </a>
            </li>
            <li class="treeview <?php echo ($activeMenu == "master") ? "active" : ""; ?>">
                   <a href="#">
                     <i class="glyphicon glyphicon-hdd"></i> <span>Master</span>
                     <i class="fa fa-angle-left pull-right"></i>
                   </a>
                   
                   <ul class="treeview-menu">
                     <li class="<?php echo ($activeTab == "users") ? "active" : ""; ?>"><a href="<?php echo base_url();?>users"><i class="fa fa-circle-o"></i> Users</a></li>
                     <li class="<?php echo ($activeTab == "barang") ? "active" : ""; ?>"><a href="<?php echo base_url();?>barang"><i class="fa fa-circle-o"></i> Barang</a></li>
                     <li class="<?php echo ($activeTab == "karyawan") ? "active" : ""; ?>"><a href="<?php echo base_url();?>karyawan"><i class="fa fa-circle-o"></i> Karyawan</a></li>
                      <!--li class="<!?php echo ($activeTab == "purchase_order") ? "active" : ""; ?>"><a href="<!?php echo base_url();?>purchase_order"><i class="fa fa-circle-o"></i> Purchase Order<span class="label label-primary  pull-right"><!?php echo jumlah_pr_id_outstanding;?></span> </a></li-->
             <li class="<?php echo ($activeTab == "suplier") ? "active" : ""; ?>"><a href="<?php echo base_url();?>suplier"><i class="fa fa-circle-o"></i> Suplier</a></li>
            

                    </ul>
           </li>
           <li class="treeview <?php echo ($activeMenu == "transaksi") ? "active" : ""; ?>">
                  <a href="#">
                    <i class="glyphicon glyphicon-transfer"></i> <span>Transaction</span>
                    <i class="fa fa-angle-left pull-right"></i>
                  </a>
                  <ul class="treeview-menu">
                    <li class="<?php echo ($activeTab == "permintaan") ? "active" : ""; ?>"><a href="<?php echo base_url();?>permintaan"><i class="fa fa-circle-o"></i> Permintaan</a></li>
                    <li class="<?php echo ($activeTab == "pembelian") ? "active" : ""; ?>"><a href="<?php echo base_url();?>pembelian"><i class="fa fa-circle-o"></i> Pembelian</a></li>

                   </ul>
          </li>

          <li class="treeview <?php echo ($activeMenu == "report") ? "active" : ""; ?>">
                 <a href="#">
                   <i class="glyphicon glyphicon-tasks"></i> <span>Reports</span>
                   <i class="fa fa-angle-left pull-right"></i>
                 </a>
                 <ul class="treeview-menu">
                   <li class="<?php echo ($activeTab == "report_permintaan") ? "active" : ""; ?>"><a href="<?php echo base_url();?>report_permintaan"><i class="fa fa-circle-o"></i> Laporan Permintaan</a></li>
                   <li class="<?php echo ($activeTab == "report_pembelian") ? "active" : ""; ?>"><a href="<?php echo base_url();?>report_pembelian"><i class="fa fa-circle-o"></i> Laporan Pembelian</a></li>
           <li class="<?php echo ($activeTab == "stok") ? "active" : ""; ?>"><a href="<?php echo base_url();?>stock"><i class="fa fa-circle-o"></i> Stok</a></li>
                  </ul>
         </li>


            </ul>
            <?php }?>
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->

        <!-- Main content -->
        <!-- /.content -->
      <!-- /.content-wrapper -->
