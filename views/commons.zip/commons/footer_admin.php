
</div><!-- ./wrapper -->
<footer class="main-footer">
<div class="pull-right hidden-xs">
          <b>Version</b> 1.0
        </div>
       <strong>Copyright &copy; 2014-2015 <a href="https://entol.net">entol.net</a>.</strong> All rights reserved.
</footer>

    <!-- jQuery 2.1.3 -->
	<!--script src="<!?php echo base_url();?>assets/plugins/jQuery/jQuery-2.1.3.min.js"></script-->
    <!-- Bootstrap 3.3.2 JS -->

    <!-- FLOT CHARTS -->
    <script src="<?php echo base_url();?>assets/plugins/flot/jquery.flot.min.js" type="text/javascript"></script>
    <!-- FLOT RESIZE PLUGIN - allows the chart to redraw when the window is resized -->
    <!-- FLOT PIE PLUGIN - also used to draw donut charts -->
    <script src="<?php echo base_url();?>assets/plugins/flot/jquery.flot.pie.min.js" type="text/javascript"></script>
     <script src="<?php echo base_url();?>assets/plugins/flot/jquery.flot.categories.min.js" type="text/javascript"></script>
    <!-- FLOT CATEGORIES PLUGIN - Used to draw bar charts -->
    <!-- jQuery 2.1.3 -->
	
    <!-- Bootstrap 3.3.2 JS -->
<!--link href="<?php echo base_url();?>assets/dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>assets/css/select2.css" rel="stylesheet" type="text/css" /-->
	
    <script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url();?>xcrud/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>

   <!-- Bootstrap WYSIHTML5 -->
	 <!-- Morris.js charts -->
    <script src="<?php echo base_url();?>assets/plugins/morris/morris.min.js" type="text/javascript"></script>
    <!-- Sparkline -->
    <script src="<?php echo base_url();?>assets/plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
    <!-- jvectormap -->
    <!-- jQuery Knob Chart -->
    <script src="<?php echo base_url();?>assets/plugins/knob/jquery.knob.js" type="text/javascript"></script>
	    <!-- Slimscroll -->
    <script src="<?php echo base_url();?>assets/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url();?>assets/plugins/chartjs/Chart.min.js" ></script>
    <!-- AdminLTE App -->
    <script src="<?php echo base_url();?>assets/dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="//maps.google.com/maps/api/js?sensor=false&language=en"></script>
	<script src="<?php echo base_url();?>assets/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/select2.js"></script>
    <script src="<?php echo base_url();?>assets/plugins/iCheck/icheck.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
	<!-- XCRUD -->
	
	
  </body>
</html>
